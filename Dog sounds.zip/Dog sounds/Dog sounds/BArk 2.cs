﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dog_sounds
{
    class BArk_2 : Together
    {
        public BArk_2()
                : base()

        {


        }
        public override string DoThing()
        {
            return "WOOF WOOF";
        }
    }
}
