﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dog_sounds
{
    class Growl : Together
    {
        public Growl()
                    : base()

        {


        }
        public override string DoThing()
        {
            return "GRRRRRRR";
        }
    }
}
