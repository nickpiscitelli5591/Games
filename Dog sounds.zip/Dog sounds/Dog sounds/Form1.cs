﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dog_sounds
{
    public partial class Form1 : Form
    {
        Together together;

        public Form1()
        {

            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.Text == "")
                MessageBox.Show("You must select a dog sound.");
            else
            {
                if (listBox1.Text == "Dog growling")
                {
                    together = new Growl();
                    together.Path = "maddog.wav";
                    label1.Text = together.DoThing();
                    pictureBox1.Image = Dog_sounds.Properties.Resources.growling;


                }
                if (listBox1.Text == "Dog barking 1")
                {
                    together = new Bark_1();
                    together.Path = "Dog Barking 101.wav";
                    label1.Text = together.DoThing();
                    pictureBox1.Image = Dog_sounds.Properties.Resources.bark1;


                }
                if (listBox1.Text == "Dog barking 2")
                {
                    together = new BArk_2();
                    together.Path = "Dog Barking 102 (1).wav";
                    label1.Text = together.DoThing();
                    pictureBox1.Image = Dog_sounds.Properties.Resources.bark2;

                }
                if (listBox1.Text == "Dog snifing")
                {
                    together = new Whine();
                    together.Path = "snif.wav";
                    label1.Text = together.DoThing();
                    pictureBox1.Image = Dog_sounds.Properties.Resources.wine;

                }
                if (listBox1.Text == "Dog howling")
                {
                    together = new Howling();
                    together.Path = "HOWL.wav";
                    label1.Text = together.DoThing();
                    pictureBox1.Image = Dog_sounds.Properties.Resources.howling;


                }

            }
            try
            {
                System.Media.SoundPlayer startSoundPlayer = new System.Media.SoundPlayer(together.Path);
                startSoundPlayer.Play();

            }
            catch
            {
                MessageBox.Show("The file for the animal sound cannot be found");
            }
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("just some dog noises");
        }

        private void blueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackColor = Color.Blue;

        }

        private void lightBlueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackColor = Color.LightBlue;

        }

        private void darkBlueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackColor = Color.DarkBlue;

        }

        private void redToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackColor = Color.Red;

        }

        private void lightRedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackColor = Color.Pink;

        }

        private void darkRedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackColor = Color.DarkRed;

        }

        private void greenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackColor = Color.Green;

        }

        private void darkGreenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackColor = Color.DarkGreen;

        }

        private void lightGreenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackColor = Color.LightGreen;


        }

        private void sortListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listBox1.Sorted = true;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Media.SoundPlayer startSoundPlayer = new System.Media.SoundPlayer("creditsss.wav");
            startSoundPlayer.Play();

            //together = new Credits();
            //together.Path = "e0000b09.wav";
            //label1.Text = together.DoThing();
            
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.akc.org/expert-advice/lifestyle/dog-sounds-meaning/");
        }
    }
}
