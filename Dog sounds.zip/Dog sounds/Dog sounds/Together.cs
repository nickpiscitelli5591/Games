﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dog_sounds
{
    class Together
    {
        protected string dogname;
        protected string path;

        public string Dogname
        {
            get { return dogname; }
            set { dogname = value; }
        }



        public string Path
        {
            get { return path; }
            set { path = value; }

        }

        public Together()
        {
            dogname = "";
            path = "";

        }
        public virtual string DoThing()
        {
            return "This animal does not know how to make a a sound";

        }
    }
}
