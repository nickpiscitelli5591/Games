﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dog_sounds
{
    class Whine : Together
    {
        public Whine()
                : base()

        {


        }
        public override string DoThing()
        {
            return "SMELLS GOOD";
        }
    }
}
