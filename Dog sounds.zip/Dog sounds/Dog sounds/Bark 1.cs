﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dog_sounds
{
    class Bark_1 : Together
    {
        public Bark_1()
                : base()

        {


        }
        public override string DoThing()
        {
            return "WOOF";
        }
    }
}
