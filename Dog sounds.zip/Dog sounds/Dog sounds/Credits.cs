﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dog_sounds
{
    class Credits:Together
    {
        public Credits()
            : base()

        {


        }
        public override string DoThing()
        {
            return "";
        }
    }
}
