﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Moonlight_Monogame
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        //color variables
        byte redIntesity = 0;
        byte greenIntensity = 80;
        byte blueIntesity = 160;

        bool redCountingup = true;
        bool greenCountingup = true;
        bool blueCountingup = true;





        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            KeyboardState keyboard = Keyboard.GetState();

            GamePadState pad1 = GamePad.GetState(PlayerIndex.One);
           
            //if (redIntesity == 255)
            //    redCountingup = false;
            //if (redIntesity == 0)
            //    redCountingup = true;
            if (pad1.Buttons.B==ButtonState.Pressed|| keyboard.IsKeyDown(Keys.R))
                redIntesity++;
            //else
            //    redIntesity--;



            //if (blueIntesity == 255)
            //    blueCountingup = false;
            //if (blueIntesity == 0)
            //    blueCountingup = true;
            if (pad1.Buttons.A == ButtonState.Pressed|| keyboard.IsKeyDown(Keys.G))
                blueIntesity++;
            //else
            //    blueIntesity--;


            //if (greenIntensity == 255)
            //    greenCountingup = false;
            //if (greenIntensity == 0)
            //    greenCountingup = true;
            if (pad1.Buttons.X == ButtonState.Pressed|| keyboard.IsKeyDown(Keys.B))
                greenIntensity++;
            //else
            //    greenIntensity--;

            if (pad1.Buttons.Y == ButtonState.Pressed|| keyboard.IsKeyDown(Keys.Y))
            {
                greenIntensity++;
                redIntesity++;
            }

            //KeyboardState keyboard = Keyboard.GetState();
            if (keyboard.IsKeyDown(Keys.Escape))
                this.Exit();



            //if (keyboard.IsKeyDown(Keys.R))
            //    redIntesity++;
            //if (keyboard.IsKeyDown(Keys.G))
            //    greenIntensity++;
            //if (keyboard.IsKeyDown(Keys.B))
            //    blueIntesity++;
            //if (keyboard.IsKeyDown(Keys.Y))
            //    redIntesity++;
            //greenIntensity++;
            if (redIntesity > 220|| greenIntensity>220||blueIntesity>220)
                GamePad.SetVibration(PlayerIndex.One, 0, 1);
            else
            {
                GamePad.SetVibration(PlayerIndex.One, 0, 0);

            }


            // TODO: Add your update logic here

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            Color backgroundColor;
            backgroundColor = new Color(redIntesity, greenIntensity, blueIntesity);

            GraphicsDevice.Clear(backgroundColor);

            // TODO: Add your drawing code here

            base.Draw(gameTime);
        }
    }
}
