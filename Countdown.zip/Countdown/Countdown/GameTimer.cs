﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Countdown
{
     class GameTimer: GameComponent

    {

        private SpriteFont font;
        private string text;
        private float time;
        private Vector2 position;
        private bool started;
        private bool paused;
        private bool finished;
        public Texture2D spriteImage;
        public Vector2 spriteLocation;

        bool drawSprite = false;


        public GameTimer(Game game, float startTime)
            :base(game)
        {
            time = startTime;
            started = false;
        paused=false;
            finished=false;
            Text = "";


        }
    #region Properties
    public SpriteFont Font
    {
        get { return font; }
        set { font = value; }


    }

    public string Text
    {
        get { return text; }
        set { text = value; }
    }
   
        public bool Started
        {
            get { return started; }
            set { started = value; }

        }
        public bool Paused
        {
            get { return paused; }
            set { paused = value; }

        }

        public bool Finished
        {
            get { return finished; }
            set { finished = value; }

        }
        public Vector2 Position
        {
            get { return position;}
            set { position = value; }

        }
        #endregion

        public override void Update(GameTime gameTime)
        {
            float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

            if(started)
            {
                if (!paused)

                {
                    if (time > 0)
                        time -= deltaTime;
                    else
                        finished = true;

                }
                if (time < 85)
                    drawSprite = true;



            }
            Text = time.ToString();









            base.Update(gameTime);


        }

        public void Draw(SpriteBatch spriteBatch)
        {
            if (drawSprite)
                spriteBatch.Draw(spriteImage, spriteLocation, Color.White);
            spriteBatch.DrawString(Font, Text, Position, Color.White);

        }














    }
}
