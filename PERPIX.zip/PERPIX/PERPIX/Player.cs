﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
namespace PERPIX
{
    class Player
    {
        Texture2D texture;
        public Rectangle rectangle;
        public Vector2 position;

        Vector2 velocity;
        Vector2 origin;

        public bool hasJumped = true;

        GraphicsDevice graphics;

        public Color[] textureData;
        public Player()
        {

        }

        public void Load(ContentManager content, GraphicsDevice newgraphics)
        {
            texture = content.Load<Texture2D>("Guysworddd");
            graphics = newgraphics;

            textureData = new Color[texture.Width * texture.Height];
            texture.GetData(textureData);
        }

        public void Update()
        {
            position += velocity;
            rectangle = new Rectangle((int)position.X, (int)position.Y, texture.Width, texture.Height);
            origin = new Vector2(rectangle.Width / 2, rectangle.Height / 2);


            if (Keyboard.GetState().IsKeyDown(Keys.A))
                velocity.X = -2f;
            else if (Keyboard.GetState().IsKeyDown(Keys.D))
                velocity.X = 2f;
            else velocity.X = 0f;

            if(Keyboard.GetState().IsKeyDown(Keys.W)&& hasJumped==false)
            {
                position.Y -= 6f;
                velocity.Y = -3f;
                hasJumped = true;
            }

            if(position.Y>=graphics.Viewport.Height - texture.Height)
            {
                position.Y = graphics.Viewport.Height - texture.Height;
                velocity.Y = 0f;
                hasJumped = false;
            }
            velocity.Y += 0.15f * 0.75f;

            
        }
        public void Draw(SpriteBatch spriteBatch)

        {
            spriteBatch.Draw(texture, rectangle, Color.White);

        }
    }
}
