﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System;

namespace Spaceyinaders
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        Texture2D bullet;
        Rectangle recbullet;

        Texture2D ship;
        Rectangle recship;

        Texture2D wintext;
        Rectangle winrec;


        Texture2D invader;
        Rectangle[,] rectinvader;

        int rows = 5;
        int cols = 1;
        String[,] invaderalive;
        int invaderspeed = 5;


        String direction = "RIGHT";

        String bulletvisible = "NO";


        SoundEffect lasershot;
        SoundEffectInstance lasershotinsatnce;
        SoundEffect invadergrunt;
        SoundEffectInstance invadergruntinsrtance;
        Song startscreensong;


        enum GameStates
        {
            title, playing, finished, win
        }
        GameStates state = GameStates.title;

        Texture2D startscreen, endscreen;
        Rectangle startrec, endrec;


        SpriteFont shotmissedfont;
        Vector2 shotmissedvector;

        SpriteFont win, win2;

        SpriteFont font;
        int shotmiss = 5;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            //graphics.IsFullScreen = true;
            //graphics.ApplyChanges();
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            this.IsMouseVisible = true;

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);


            invader = Content.Load<Texture2D>("droidd");
            rectinvader = new Rectangle[rows, cols];
            invaderalive = new String[rows, cols];

            for (int r = 0; r < rows; r++)
                for (int c = 0; c < cols; c++)
                {
                    rectinvader[r, c].Width = invader.Width;
                    rectinvader[r, c].Height = invader.Height;
                    rectinvader[r, c].X = 60 * c;
                    rectinvader[r, c].Y = 60 * r;
                    invaderalive[r, c] = "YES";


                }
            ship = Content.Load<Texture2D>("clonetrooperr");
            recship.Width = ship.Width;
            recship.Height = ship.Height;
            recship.X = 0;
            recship.Y = 400;


            bullet = Content.Load<Texture2D>("redd");
            recbullet.Width = bullet.Width;
            recbullet.Height = bullet.Height;
            recbullet.X = 0;
            recbullet.Y = 0;


            lasershot = Content.Load<SoundEffect>("phasers3");
            lasershotinsatnce = lasershot.CreateInstance();
            invadergrunt = Content.Load<SoundEffect>("yay");
            invadergruntinsrtance = invadergrunt.CreateInstance();

            startscreensong = Content.Load<Song>("starwars");
            MediaPlayer.Play(startscreensong);
            MediaPlayer.Volume = .50f;
            MediaPlayer.IsRepeating = true;

            startscreen = Content.Load<Texture2D>("starss");
            startrec = new Rectangle(0, 0, 800, 480);
            endscreen = Content.Load<Texture2D>("lose");
            endrec = new Rectangle(0, 0, 800, 480);

            win = Content.Load<SpriteFont>("win");
            win2=Content.Load<SpriteFont>("win2");

            font = Content.Load<SpriteFont>("font");

            shotmissedfont = Content.Load<SpriteFont>("shot");
            shotmissedvector = new Vector2(10, 10);

            winrec = new Rectangle(0, 0, 800, 600);
            wintext = Content.Load<Texture2D>("galaxyy");






            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            KeyboardState kb = Keyboard.GetState();
            if (kb.IsKeyDown(Keys.Escape))
            {
                this.Exit();
            }

            switch (state)
            {

                case GameStates.title:
                    UpdateTitleScreeen();
                    break;
                case GameStates.playing:
                    UpdateGamePlay();
                    break;
                case GameStates.finished:
                    UpdateEndScreen();
                    break;
                case GameStates.win:
                    UpdateWin();
                    break;






            }

            base.Update(gameTime);
        }
        private void UpdateWin()
        {
            KeyboardState kb = Keyboard.GetState();
            if (kb.IsKeyDown(Keys.V))
            {
                state = GameStates.title;
                RESET();

            }
        }
        private void UpdateTitleScreeen()
        {
           
            KeyboardState kb = Keyboard.GetState();
            if (kb.IsKeyDown(Keys.Enter))
            {

                state = GameStates.playing;
                RESET();


            }
        }
        private void UpdateEndScreen()
        {
            MouseState mouse = Mouse.GetState();
            if (mouse.LeftButton == ButtonState.Pressed || mouse.RightButton == ButtonState.Pressed)
            {

                state = GameStates.title;
                


            }

        }
        

        private void UpdateGamePlay()
        {
           


            KeyboardState kb = Keyboard.GetState();
            int rightside = graphics.GraphicsDevice.Viewport.Width;
            int leftside = 0;

            for (int r = 0; r < rows; r++)

                for (int c = 0; c < cols; c++)
                {
                    if (direction.Equals("RIGHT"))
                        rectinvader[r, c].X = rectinvader[r, c].X + invaderspeed;


                    if (direction.Equals("LEFT"))
                        rectinvader[r, c].X = rectinvader[r, c].X - invaderspeed;

                }

            String changeddirection = "N";
            for (int r = 0; r < rows; r++)
                for (int c = 0; c < cols; c++)
                {
                    if (invaderalive[r, c].Equals("YES"))
                    {
                        if (rectinvader[r, c].X + rectinvader[r, c].Width > rightside)
                        {
                            direction = "LEFT";
                            changeddirection = "Y";

                        }
                        if (rectinvader[r, c].X < leftside)
                        {
                            direction = "RIGHT";
                            changeddirection = "Y";

                        }


                    }
                }



            if (changeddirection.Equals("Y"))
            {
                for (int r = 0; r < rows; r++)
                    for (int c = 0; c < cols; c++)
                        rectinvader[r, c].Y = rectinvader[r, c].Y + 10;


            }
            if (kb.IsKeyDown(Keys.Left))
                recship.X = recship.X - 5;
            if (kb.IsKeyDown(Keys.Right))
                recship.X = recship.X + 5;
           


            if (recship.X < 0)
                recship.X = 0;
            if (recship.X > GraphicsDevice.Viewport.Width)
                recship.X = GraphicsDevice.Viewport.Width - ship.Width;



            if (kb.IsKeyDown(Keys.Space) && bulletvisible.Equals("NO"))
            {

                bulletvisible = "YES";
                lasershotinsatnce.Play();
                recbullet.X = recship.X + (recship.Width / 2) - 1;
                recbullet.Y = recship.Y - recbullet.Height + 6;

            }

            if (bulletvisible.Equals("YES"))
                recbullet.Y = recbullet.Y - 5;

            if (bulletvisible.Equals("YES"))
                for (int r = 0; r < rows; r++)
                    for (int c = 0; c < cols; c++)
                    {
                        if (invaderalive[r, c].Equals("YES"))
                            if (recbullet.Intersects(rectinvader[r, c]))
                            {
                                bulletvisible = "NO";
                                invaderalive[r, c] = "NO";
                                invadergruntinsrtance.Play();

                            }
                    }



            if (recbullet.Y + recbullet.Height < 0)
            {
                bulletvisible = "NO";
                shotmiss--;
                recbullet.X = recship.X + (recship.Width / 2) - 1;
                recbullet.Y = recship.Y - recbullet.Height + 3;



            }
            if (shotmiss == 0)
            {
                RESET();
                state = GameStates.finished;
                

            }

            int count = 0;
            for (int r = 0; r < rows; r++)
                for (int c = 0; c < cols; c++)
                    if (invaderalive[r, c].Equals("YES"))
                        count++;

            if (count > (rows * cols / 2))
                invaderspeed = 3;

            if (count < (rows * cols / 2))
                invaderspeed = 7;

            if (count == 0)
            {
                state = GameStates.win;
                
            }


            for (int r = 0; r < rows; r++)
                for (int c = 0; c < cols; c++)
                {
                    if (invaderalive[r, c].Equals("YES"))
                        if (rectinvader[r, c].Y + rectinvader[r, c].Height > recship.Y)
                            state = GameStates.finished;

                }

        }

      


            // TODO: Add your update logic here

         
        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);
            spriteBatch.Begin();
          
            switch(state)
            {

                case GameStates.title:
                    DrawTitleScreen();
                    break;
                case GameStates.playing:
                    DrawGamePlay();
                    break;
                case GameStates.finished:
                    DrawEndscreen();
                    break;
                case GameStates.win:
                    Drawwin();
                    break;




            }

            spriteBatch.End();

            // TODO: Add your drawing code here

            base.Draw(gameTime);
        }
        private void Drawwin()
        {
            spriteBatch.Draw(wintext, winrec, Color.White);
            spriteBatch.DrawString(win,"Click V to return to start screen",new Vector2(200,200),Color.Red);
            spriteBatch.DrawString(win2, "YOU SAVED THE GALAXY", new Vector2(100, 400), Color.Red);



        }
        private void DrawTitleScreen()
        {
            spriteBatch.Draw(startscreen, startrec, Color.White);
        }
        private void RESET()
        {
           // state = GameStates.title;

            for (int r = 0; r < rows; r++)
                for (int c = 0; c < cols; c++)
                {

                    rectinvader[r, c].Width = invader.Width;
                    rectinvader[r, c].Height = invader.Height;
                    rectinvader[r, c].X = 60 * c;
                    rectinvader[r, c].Y = 60 * r;
                    invaderalive[r,c] = "YES";
                    shotmiss = 5;

                }
            MediaPlayer.Play(startscreensong);
        }
        private void DrawGamePlay()
        {
            for (int r = 0; r < rows; r++)
                for (int c = 0; c < cols; c++)

                    if (invaderalive[r, c].Equals("YES"))
                        spriteBatch.Draw(invader, rectinvader[r, c], Color.White);

            spriteBatch.Draw(ship, recship, Color.White);


            if (bulletvisible.Equals("YES"))
                spriteBatch.Draw(bullet, recbullet, Color.White);

            spriteBatch.DrawString(shotmissedfont, "Misfires left:" + shotmiss.ToString(), shotmissedvector,Color.White);

        }
        private void DrawEndscreen()
        {
            spriteBatch.Draw(endscreen, endrec, Color.White);
            spriteBatch.DrawString(font, "Click the MOUSE to play again", new Vector2(200, 200), Color.Red);
            
        }
       
    }
}
