﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Bouncin_ball
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        Texture2D myTextures;
        Rectangle myRec;

        Texture2D Battexture;
        Rectangle batRec;
    

        Vector2 veolocity;

       System. Random myrand = new System.Random();


        
        //Screen parameters
        int screenwidth;
        int screeenheight;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);


            myTextures = Content.Load<Texture2D>("Green shelll");
            myRec = new Rectangle(100, 100, 50, 50);

            Battexture = Content.Load<Texture2D>("Mario 1");
            batRec = new Rectangle(200, 200, 300, 200);

           


            veolocity.X = 3f;
            veolocity.Y = 3f;


            RandomLoad();



            screenwidth = GraphicsDevice.Viewport.Width;
            screeenheight = GraphicsDevice.Viewport.Height;

            


            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();


            if (Keyboard.GetState().IsKeyDown(Keys.Right))
                batRec.X += 6;
            if (Keyboard.GetState().IsKeyDown(Keys.Left))
                batRec.X -= 6;

            if (myRec.Intersects(batRec))
                veolocity.Y = -veolocity.Y;


            //if (Keyboard.GetState().IsKeyDown(Keys.Right))
            //    myRec.X += 3;
            //if (Keyboard.GetState().IsKeyDown(Keys.Left))
            //    myRec.X -= 3;
            //if (Keyboard.GetState().IsKeyDown(Keys.Up))
            //    myRec.Y -= 3;
            //if (Keyboard.GetState().IsKeyDown(Keys.Down))
            //    myRec.Y += 3;
            myRec.X = myRec.X + (int)veolocity.X;
            myRec.Y = myRec.Y + (int)veolocity.Y;

            if(Keyboard.GetState().IsKeyDown(Keys.Space))

            {
                myRec.X = 300;
                myRec.Y = 300;
                RandomLoad();
            }



            if (myRec.X <= 0)
                veolocity.X = -veolocity.X;

            
            if (myRec.Y <= 0)
                veolocity.Y = -veolocity.Y;


            if (myRec.X + myTextures.Width >= screenwidth)
                veolocity.X = -veolocity.X;
            if (myRec.Y + myTextures.Height >= screeenheight)
                veolocity.Y= -veolocity.Y;            // TODO: Add your update logic here


           
            base.Update(gameTime);
        }
        void RandomLoad()
        {
            int random = myrand.Next(0, 4);
            if(random==0)
            {
                veolocity.X = 3f;
                veolocity.Y = 3f;

            }
            if (random == 1)
            {
                veolocity.X = -3f;
                veolocity.Y = 3f;

            }
            if (random == 2)
            {
                veolocity.X = -3f;
                veolocity.Y = -3f;

            }
            if (random == 3)
            {
                veolocity.X = 3f;
                veolocity.Y = -3f;

            }


        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.White);

            spriteBatch.Begin();
            spriteBatch.Draw(myTextures, myRec, Color.White);

            spriteBatch.Draw(Battexture, batRec, Color.White);

            spriteBatch.End();


            base.Draw(gameTime);
        }
    }
}
