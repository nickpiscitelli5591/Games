﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car
{
    class Car
    {

        public Car()
        {
            newPrice = 0;
            newcolor = "";
           
            newPassengers = 0;
            newType = "";


        }

        public Car(int Price, string Color, string Tires, int Passengers,string Type)
        {
            newPrice = Price;
            newcolor = Color;
          
            newPassengers = Passengers;
            newType = Type;


        }

        public string getcolor(string color)
        {
            return newcolor;
        }
        public int getPrice()
        {
            return newPrice;
        }
     
        public int getpassengers()
        {
            return newPassengers;
        }
        public string getType()
        {
            return newType;
        }


        private int newPassengers;
    
            private int newPrice;
        private string newcolor;
        private string newType;















    }
}
