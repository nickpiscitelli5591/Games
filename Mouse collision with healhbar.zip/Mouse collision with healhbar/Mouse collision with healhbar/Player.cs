﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
namespace Mouse_collision_with_healhbar
{
    class Player
    {
        Texture2D texture;
        public Rectangle rectangle;
        public Vector2 position;

        public int health;
        

        public Player(Texture2D newTexture, Vector2 newPosition, int newHealth)
        {
            texture = newTexture;
            position = newPosition;

            health = newHealth;
        }

        public void Update()
        {
            rectangle = new Rectangle((int)position.X, (int)position.Y, 200, 200);

        }

        public void draw(SpriteBatch spriteBatch)
        {
            if (health > 0)
                spriteBatch.Draw(texture, rectangle, Color.White);
        }
    }
}
